# October 2023
# Author: Data Wizard

print("   /|")
print("  / |")
print(" /  |")
print("/___|")




print("   2015|                           _")
print("       |                          | |")
print("       |       _                  | |")
print("   2010|      | |                 | |")
print("       |      | |                 | |")
print("       |      | |                 | |")
print("   2005|      | |         _       | |")
print("       |      | |        | |      | |")
print("       |      | |        | |      | |")
print("   2000|      | |        | |      | |")
print("       _______|_|________|_|______|_|_____")
print("              men       women   children")

print("The bar chart illustrates information about usage of phone in Uzbekistan")