# October 2023
# Author: Data Wizard
print("Hello world")